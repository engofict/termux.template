# Termux interface and theme creat by hacker somali
<img src="https://www.pngkey.com/maxpic/u2w7w7u2i1a9w7e6/" >
#### Beautify theme for Termux App With a warm welcome by yahya in 16-octuber-2020

## [+] Installation & Usage
```
apt update
apt install git -y
pkg install mpv -y
git clone https://github.com/fikrado/qurxin
cd qurxin
chmod +x *
sh install.sh
exit
```
### or use Single Command
```
apt update && apt install git -y && pkg install mpv && git clone https://github.com/fikrado/qurxin && cd qurxin && chmod +x * && ./install.sh
```
## [+]How to remove 
```
cd qurxin

bash rvt.sh
```
# thanks to https://github.com/fikrado 
 # For providing the code

    
## [+] Find Me on :
##### https://instagram.com/mr__yahye

