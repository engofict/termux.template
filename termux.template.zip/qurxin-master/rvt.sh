pip install bs4
cd
cd ..
cd usr/etc
rm bash.bashrc
cd $HOME/qurxin/Revert
mv bash.bashrc $PREFIC/etc
python $HOME/qurxin/Revert/Thanks.py
